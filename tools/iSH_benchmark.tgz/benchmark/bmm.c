#include <stdio.h>
#include <time.h>

#ifndef ITERATIONS
#define ITERATIONS 1000000000
#endif

/* Empty asm barrier: makes the accumulator opaque each iteration so -O2
 * cannot fold the loop into a closed form or vectorize it away, while
 * adding zero instructions. Harmless at -O0. Without it, an optimized
 * build of the integer loop measures nothing (gcc computes the sum at
 * compile time). */
#define KEEP(x) __asm__ volatile("" : "+r"(x))

void benchmark_integer() {
    long long sum = 0;
    for (long long i = 0; i < ITERATIONS; ++i) {
        sum += i;
        KEEP(sum);
    }
    printf("Integer sum: %lld\n", sum);
}

void benchmark_float() {
    double sum = 0.0;
    for (double i = 0.0; i < ITERATIONS; ++i) {
        sum += i;
        KEEP(sum);
    }
    printf("Floating point sum: %f\n", sum);
}

int main() {
    clock_t start, end;
    double cpu_time_used;

    start = clock();
    benchmark_integer();
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Integer benchmark completed in %f seconds\n", cpu_time_used);

    start = clock();
    benchmark_float();
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
    printf("Floating point benchmark completed in %f seconds\n", cpu_time_used);

    return 0;
}

