#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define NUM_THREADS 10000

// Thread function that does minimal work
void* thread_func(void* arg) {
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    int rc;
    clock_t start, end;
    double time_taken;

    start = clock();

    // Create a number of threads
    for (long i = 0; i < NUM_THREADS; i++) {
        rc = pthread_create(&threads[i], NULL, thread_func, (void *)i);
        if (rc) {
            printf("ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    // Join the threads
    for (long i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    end = clock();
    time_taken = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("Thread creation and destruction took %f seconds\n", time_taken);
    return 0;
}

